import Hero from "../components/sections/Home/Hero";

export default function HomePage () {

    return (

        <>
        
            <Hero/>

        </>

    )

}